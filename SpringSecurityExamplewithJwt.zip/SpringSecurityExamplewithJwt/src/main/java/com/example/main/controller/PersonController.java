package com.example.main.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.main.model.Person;

import java.util.ArrayList;
import java.util.List;

@RestController
public class PersonController {

    private List<Person> persons = new ArrayList<>(
            List.of(
                    new Person(1, "navaneeth", 60),
                    new Person(2, "lakshman", 65)
            ));


    @GetMapping("/getpersons")
    public List<Person> getPerson() {
        return persons;
    }

    @GetMapping("/csrf-token")
    public CsrfToken getCsrfToken(HttpServletRequest request) {
        return (CsrfToken) request.getAttribute("_csrf");


    }


    @PostMapping("/addperson")
    public Person addPerson(@RequestBody Person person) {
    	persons.add(person);
        return person;
    }

}
