package com.example.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.main.model.Users;
import com.example.main.repo.UserRepo;

@Service
public class UserService {

    @Autowired
    private UserRepo repo;
    
    @Autowired
    private AuthenticationManager authmang;
    
    @Autowired
    private JwtService jwtservice;


    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    public Users register(Users user) {
        user.setPassword(encoder.encode(user.getPassword()));
        repo.save(user);
        return user;
    }

	public String verifylogin(Users user) {
		
		Authentication auth= authmang.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),user.getPassword()));
		
		if(auth.isAuthenticated()) {
			return jwtservice.verifylogin(user.getUsername());
		}
		
		return "fail";
	}

}
