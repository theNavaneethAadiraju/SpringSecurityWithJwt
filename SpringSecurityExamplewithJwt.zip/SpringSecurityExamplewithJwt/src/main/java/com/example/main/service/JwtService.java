package com.example.main.service;

import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
	
	private String secretKey="";
	
	
	public JwtService() {
		
		try {
			KeyGenerator temp= KeyGenerator.getInstance("HmacSHA512");
			SecretKey sk= temp.generateKey();
			secretKey= Base64.getEncoder().encodeToString(sk.getEncoded());
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public String verifylogin(String username) {
		
		Map<String,Object> map= new HashMap();
			
		return Jwts.builder().claims().add(map).subject(username)
				.issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis()+ 60*60*10))
				.and().signWith(getKey()).compact();
		
	}

	private SecretKey getKey() {
		// TODO Auto-generated method stub
		byte[] bytekey = Decoders.BASE64.decode(secretKey);
		
		return Keys.hmacShaKeyFor(bytekey) ;
	}

}
